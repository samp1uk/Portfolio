﻿namespace Program1
{
    partial class Program1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Program1));
            this.widthbox = new System.Windows.Forms.TextBox();
            this.Titlelabel = new System.Windows.Forms.Label();
            this.widthlabel = new System.Windows.Forms.Label();
            this.lengthbox = new System.Windows.Forms.TextBox();
            this.carpetpricebox = new System.Windows.Forms.TextBox();
            this.paddingbox = new System.Windows.Forms.TextBox();
            this.firstroombox = new System.Windows.Forms.TextBox();
            this.yardsneeded = new System.Windows.Forms.TextBox();
            this.costofcarpet = new System.Windows.Forms.TextBox();
            this.costofpadding = new System.Windows.Forms.TextBox();
            this.costoflabor = new System.Windows.Forms.TextBox();
            this.totalcost = new System.Windows.Forms.TextBox();
            this.lengthlabel = new System.Windows.Forms.Label();
            this.carpetpricelabel = new System.Windows.Forms.Label();
            this.paddinglabel = new System.Windows.Forms.Label();
            this.firstroomlabel = new System.Windows.Forms.Label();
            this.yardsneedlabel = new System.Windows.Forms.Label();
            this.carpetcostlabel = new System.Windows.Forms.Label();
            this.paddingcostlabel = new System.Windows.Forms.Label();
            this.laborcostlabel = new System.Windows.Forms.Label();
            this.costlabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Inputlabel = new System.Windows.Forms.Label();
            this.outputlabel = new System.Windows.Forms.Label();
            this.clearbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // widthbox
            // 
            this.widthbox.Location = new System.Drawing.Point(249, 85);
            this.widthbox.Margin = new System.Windows.Forms.Padding(2);
            this.widthbox.Name = "widthbox";
            this.widthbox.Size = new System.Drawing.Size(76, 20);
            this.widthbox.TabIndex = 0;
            // 
            // Titlelabel
            // 
            this.Titlelabel.AutoSize = true;
            this.Titlelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Titlelabel.Location = new System.Drawing.Point(73, 20);
            this.Titlelabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Titlelabel.Name = "Titlelabel";
            this.Titlelabel.Size = new System.Drawing.Size(388, 20);
            this.Titlelabel.TabIndex = 1;
            this.Titlelabel.Text = "Welcome to the Handy-Dandy Carpet Estimator";
            // 
            // widthlabel
            // 
            this.widthlabel.AutoSize = true;
            this.widthlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.widthlabel.Location = new System.Drawing.Point(23, 86);
            this.widthlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.widthlabel.Name = "widthlabel";
            this.widthlabel.Size = new System.Drawing.Size(207, 15);
            this.widthlabel.TabIndex = 2;
            this.widthlabel.Text = "Enter the max width of room (in feet):";
            // 
            // lengthbox
            // 
            this.lengthbox.Location = new System.Drawing.Point(249, 125);
            this.lengthbox.Margin = new System.Windows.Forms.Padding(2);
            this.lengthbox.Name = "lengthbox";
            this.lengthbox.Size = new System.Drawing.Size(76, 20);
            this.lengthbox.TabIndex = 3;
            // 
            // carpetpricebox
            // 
            this.carpetpricebox.Location = new System.Drawing.Point(249, 166);
            this.carpetpricebox.Margin = new System.Windows.Forms.Padding(2);
            this.carpetpricebox.Name = "carpetpricebox";
            this.carpetpricebox.Size = new System.Drawing.Size(76, 20);
            this.carpetpricebox.TabIndex = 4;
            // 
            // paddingbox
            // 
            this.paddingbox.Location = new System.Drawing.Point(249, 210);
            this.paddingbox.Margin = new System.Windows.Forms.Padding(2);
            this.paddingbox.Name = "paddingbox";
            this.paddingbox.Size = new System.Drawing.Size(76, 20);
            this.paddingbox.TabIndex = 5;
            // 
            // firstroombox
            // 
            this.firstroombox.Location = new System.Drawing.Point(249, 254);
            this.firstroombox.Margin = new System.Windows.Forms.Padding(2);
            this.firstroombox.Name = "firstroombox";
            this.firstroombox.Size = new System.Drawing.Size(76, 20);
            this.firstroombox.TabIndex = 6;
            // 
            // yardsneeded
            // 
            this.yardsneeded.Location = new System.Drawing.Point(465, 85);
            this.yardsneeded.Margin = new System.Windows.Forms.Padding(2);
            this.yardsneeded.Name = "yardsneeded";
            this.yardsneeded.ReadOnly = true;
            this.yardsneeded.Size = new System.Drawing.Size(76, 20);
            this.yardsneeded.TabIndex = 7;
            this.yardsneeded.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // costofcarpet
            // 
            this.costofcarpet.Location = new System.Drawing.Point(465, 127);
            this.costofcarpet.Margin = new System.Windows.Forms.Padding(2);
            this.costofcarpet.Name = "costofcarpet";
            this.costofcarpet.ReadOnly = true;
            this.costofcarpet.Size = new System.Drawing.Size(76, 20);
            this.costofcarpet.TabIndex = 8;
            this.costofcarpet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // costofpadding
            // 
            this.costofpadding.Location = new System.Drawing.Point(465, 170);
            this.costofpadding.Margin = new System.Windows.Forms.Padding(2);
            this.costofpadding.Name = "costofpadding";
            this.costofpadding.ReadOnly = true;
            this.costofpadding.Size = new System.Drawing.Size(76, 20);
            this.costofpadding.TabIndex = 9;
            this.costofpadding.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // costoflabor
            // 
            this.costoflabor.Location = new System.Drawing.Point(465, 211);
            this.costoflabor.Margin = new System.Windows.Forms.Padding(2);
            this.costoflabor.Name = "costoflabor";
            this.costoflabor.ReadOnly = true;
            this.costoflabor.Size = new System.Drawing.Size(76, 20);
            this.costoflabor.TabIndex = 10;
            this.costoflabor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // totalcost
            // 
            this.totalcost.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalcost.Location = new System.Drawing.Point(465, 254);
            this.totalcost.Margin = new System.Windows.Forms.Padding(2);
            this.totalcost.Name = "totalcost";
            this.totalcost.ReadOnly = true;
            this.totalcost.Size = new System.Drawing.Size(76, 20);
            this.totalcost.TabIndex = 11;
            this.totalcost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lengthlabel
            // 
            this.lengthlabel.AutoSize = true;
            this.lengthlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lengthlabel.Location = new System.Drawing.Point(23, 127);
            this.lengthlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lengthlabel.Name = "lengthlabel";
            this.lengthlabel.Size = new System.Drawing.Size(212, 15);
            this.lengthlabel.TabIndex = 12;
            this.lengthlabel.Text = "Enter the max length of room (in feet):";
            // 
            // carpetpricelabel
            // 
            this.carpetpricelabel.AutoSize = true;
            this.carpetpricelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.carpetpricelabel.Location = new System.Drawing.Point(23, 168);
            this.carpetpricelabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.carpetpricelabel.Name = "carpetpricelabel";
            this.carpetpricelabel.Size = new System.Drawing.Size(200, 15);
            this.carpetpricelabel.TabIndex = 13;
            this.carpetpricelabel.Text = "Enter the carpet price (per sq. yard):";
            // 
            // paddinglabel
            // 
            this.paddinglabel.AutoSize = true;
            this.paddinglabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paddinglabel.Location = new System.Drawing.Point(23, 210);
            this.paddinglabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.paddinglabel.Name = "paddinglabel";
            this.paddinglabel.Size = new System.Drawing.Size(213, 15);
            this.paddinglabel.TabIndex = 14;
            this.paddinglabel.Text = "Enter layers of padding to use (1 or 2):";
            // 
            // firstroomlabel
            // 
            this.firstroomlabel.AutoSize = true;
            this.firstroomlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstroomlabel.Location = new System.Drawing.Point(23, 256);
            this.firstroomlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.firstroomlabel.Name = "firstroomlabel";
            this.firstroomlabel.Size = new System.Drawing.Size(220, 15);
            this.firstroomlabel.TabIndex = 15;
            this.firstroomlabel.Text = "Is this the first room? (1 = YES, 0 = NO):";
            // 
            // yardsneedlabel
            // 
            this.yardsneedlabel.AutoSize = true;
            this.yardsneedlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yardsneedlabel.Location = new System.Drawing.Point(352, 85);
            this.yardsneedlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.yardsneedlabel.Name = "yardsneedlabel";
            this.yardsneedlabel.Size = new System.Drawing.Size(109, 15);
            this.yardsneedlabel.TabIndex = 16;
            this.yardsneedlabel.Text = "Sq. Yards Needed:";
            // 
            // carpetcostlabel
            // 
            this.carpetcostlabel.AutoSize = true;
            this.carpetcostlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.carpetcostlabel.Location = new System.Drawing.Point(352, 127);
            this.carpetcostlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.carpetcostlabel.Name = "carpetcostlabel";
            this.carpetcostlabel.Size = new System.Drawing.Size(73, 15);
            this.carpetcostlabel.TabIndex = 17;
            this.carpetcostlabel.Text = "Carpet Cost:";
            // 
            // paddingcostlabel
            // 
            this.paddingcostlabel.AutoSize = true;
            this.paddingcostlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paddingcostlabel.Location = new System.Drawing.Point(352, 168);
            this.paddingcostlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.paddingcostlabel.Name = "paddingcostlabel";
            this.paddingcostlabel.Size = new System.Drawing.Size(83, 15);
            this.paddingcostlabel.TabIndex = 18;
            this.paddingcostlabel.Text = "Padding Cost:";
            // 
            // laborcostlabel
            // 
            this.laborcostlabel.AutoSize = true;
            this.laborcostlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laborcostlabel.Location = new System.Drawing.Point(352, 211);
            this.laborcostlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.laborcostlabel.Name = "laborcostlabel";
            this.laborcostlabel.Size = new System.Drawing.Size(69, 15);
            this.laborcostlabel.TabIndex = 19;
            this.laborcostlabel.Text = "Labor Cost:";
            // 
            // costlabel
            // 
            this.costlabel.AutoSize = true;
            this.costlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.costlabel.Location = new System.Drawing.Point(352, 256);
            this.costlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.costlabel.Name = "costlabel";
            this.costlabel.Size = new System.Drawing.Size(64, 15);
            this.costlabel.TabIndex = 20;
            this.costlabel.Text = "Total Cost:";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(57, 301);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(227, 63);
            this.button1.TabIndex = 21;
            this.button1.Text = "Calculate ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Inputlabel
            // 
            this.Inputlabel.AutoSize = true;
            this.Inputlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Inputlabel.Location = new System.Drawing.Point(23, 56);
            this.Inputlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Inputlabel.Name = "Inputlabel";
            this.Inputlabel.Size = new System.Drawing.Size(49, 13);
            this.Inputlabel.TabIndex = 22;
            this.Inputlabel.Text = "INPUT:";
            // 
            // outputlabel
            // 
            this.outputlabel.AutoSize = true;
            this.outputlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputlabel.Location = new System.Drawing.Point(352, 57);
            this.outputlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.outputlabel.Name = "outputlabel";
            this.outputlabel.Size = new System.Drawing.Size(62, 13);
            this.outputlabel.TabIndex = 23;
            this.outputlabel.Text = "OUTPUT:";
            // 
            // clearbutton
            // 
            this.clearbutton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.clearbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearbutton.Location = new System.Drawing.Point(383, 301);
            this.clearbutton.Margin = new System.Windows.Forms.Padding(2);
            this.clearbutton.Name = "clearbutton";
            this.clearbutton.Size = new System.Drawing.Size(109, 63);
            this.clearbutton.TabIndex = 24;
            this.clearbutton.Text = "Clear";
            this.clearbutton.UseVisualStyleBackColor = true;
            this.clearbutton.Click += new System.EventHandler(this.clearbutton_Click);
            // 
            // Program1
            // 
            this.AcceptButton = this.button1;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.clearbutton;
            this.ClientSize = new System.Drawing.Size(560, 385);
            this.Controls.Add(this.clearbutton);
            this.Controls.Add(this.outputlabel);
            this.Controls.Add(this.Inputlabel);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.costlabel);
            this.Controls.Add(this.laborcostlabel);
            this.Controls.Add(this.paddingcostlabel);
            this.Controls.Add(this.carpetcostlabel);
            this.Controls.Add(this.yardsneedlabel);
            this.Controls.Add(this.firstroomlabel);
            this.Controls.Add(this.paddinglabel);
            this.Controls.Add(this.carpetpricelabel);
            this.Controls.Add(this.lengthlabel);
            this.Controls.Add(this.totalcost);
            this.Controls.Add(this.costoflabor);
            this.Controls.Add(this.costofpadding);
            this.Controls.Add(this.costofcarpet);
            this.Controls.Add(this.yardsneeded);
            this.Controls.Add(this.firstroombox);
            this.Controls.Add(this.paddingbox);
            this.Controls.Add(this.carpetpricebox);
            this.Controls.Add(this.lengthbox);
            this.Controls.Add(this.widthlabel);
            this.Controls.Add(this.Titlelabel);
            this.Controls.Add(this.widthbox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Program1";
            this.Text = "Handy-Dandy Carpet Estimator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox widthbox;
        private System.Windows.Forms.Label Titlelabel;
        private System.Windows.Forms.Label widthlabel;
        private System.Windows.Forms.TextBox lengthbox;
        private System.Windows.Forms.TextBox carpetpricebox;
        private System.Windows.Forms.TextBox paddingbox;
        private System.Windows.Forms.TextBox firstroombox;
        private System.Windows.Forms.TextBox yardsneeded;
        private System.Windows.Forms.TextBox costofcarpet;
        private System.Windows.Forms.TextBox costofpadding;
        private System.Windows.Forms.TextBox costoflabor;
        private System.Windows.Forms.TextBox totalcost;
        private System.Windows.Forms.Label lengthlabel;
        private System.Windows.Forms.Label carpetpricelabel;
        private System.Windows.Forms.Label paddinglabel;
        private System.Windows.Forms.Label firstroomlabel;
        private System.Windows.Forms.Label yardsneedlabel;
        private System.Windows.Forms.Label carpetcostlabel;
        private System.Windows.Forms.Label paddingcostlabel;
        private System.Windows.Forms.Label laborcostlabel;
        private System.Windows.Forms.Label costlabel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label Inputlabel;
        private System.Windows.Forms.Label outputlabel;
        private System.Windows.Forms.Button clearbutton;
    }
}

